str = "C1CBC6C0FCC9E8ABA7DEE8F2A7F4EFE8F2EBE3A7E9E8F3A7F7E6F4F4A7F3EFE2A7E1EBE6E0FA"

magic = 135

output = ""

for i in range(0, len(str), 2) :
  output += chr(int(str[i:i+2], 16) ^ magic)

print output
