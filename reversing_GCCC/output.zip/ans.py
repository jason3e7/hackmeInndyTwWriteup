from z3 import *

s = Solver()

x = BitVec('x', 32)
data = [164,25,4,130,126,158,91,199,173,252,239,143,150,251,126,39,104,104,146,208,249,9,219,208,101,182,62,92,6,27,5,46]
result = [0] * 32
b = 0

# don't forget Control Flow
s.add(x >= 2 ** 31)
s.add(x <= (2 ** 32 - 1))

# s.add(x < 2 ** 31) <==> s.add(x < 0)
#print s

for i in range(0, 32) :
  result[i] = data[i] ^ (x & 0xff) ^ b
  b = (b ^ data[i]) & 0xff
# x >>= 1, unsigned
  x = LShR(x, 1)

s.add(result[0] == ord("F"))
s.add(result[1] == ord("L"))
s.add(result[2] == ord("A"))
s.add(result[3] == ord("G"))
s.add(result[4] == ord("{"))
for i in range(5, 31) :
  s.add(Or(And(result[i] >= ord("A"), result[i] <= ord("Z")), (result[i] == ord(" ")), (result[i] == ord("{")), (result[i] == ord("}"))))
s.add(result[31] == ord("}"))

#print s

print s.check()
if s.check() == sat:
  print s.model()
