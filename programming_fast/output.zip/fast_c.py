from pwn import *
import ctypes
dyn = ctypes.cdll.LoadLibrary('cal.so')

r = remote('hackme.inndy.tw', 7707)
for x in range(3):
  r.recvline()
r.sendline("Yes I know")

for x in range(10000):
  q = r.recvline()
  arr = q.split()

  ans = dyn.cal(int(arr[0]), ord(arr[1]), int(arr[2]))
  r.sendline(str(ans))

print r.recvline()
