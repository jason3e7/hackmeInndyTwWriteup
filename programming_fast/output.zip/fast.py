from pwn import *
import numpy as np
import math

r = remote('hackme.inndy.tw', 7707)
for x in range(3):
  r.recvline()
r.sendline("Yes I know")

for x in range(10000):
  q = r.recvline()
  arr = q.split()
  num1 = np.int32(arr[0])
  num2 = np.int32(arr[2])
  count = np.int32(0)

  if(arr[1] == '+') :
    count = num1 + num2
  elif(arr[1] == '-') :
    count = num1 - num2
  elif(arr[1] == '*') :
    count = num1 * num2
  elif(arr[1] == '/') :
    if((num1 > 0 and num2 < 0) or (num2 > 0 and num1 < 0)) :
      count = (-1 * ((-1 * num1) / num2)) 
    else :
      count = num1 / num2
  else :
    count = np.int32(-1)

  r.sendline(str(count))

print r.recvline()
