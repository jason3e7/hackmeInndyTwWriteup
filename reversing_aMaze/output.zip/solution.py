import binascii
import string

f = open("file", "rb")
mapBin = f.read()
f.close()

mapHex = binascii.hexlify(mapBin)

def hexToInt(s) : 
  s = [s[i:i+2] for i in range(0, len(s), 2)]
  s = s[::-1]
  s = "".join(s)
  return int(s, 16)

def findMap(base, c):
  #print hex(base << 9)
  local = ((base << 9) + 4 * c)

  # mean word not byte, * 2
  local *= 2  
  return hexToInt(mapHex[local:local+8])

def findNext(level, base) :
  for c in string.printable :
    temp = findMap(base, ord(c))
    if (temp != 0) :
      if (temp == 0xffffffff) : 
        return ""
      print level, c, hex(temp)
      n = findNext(level + 1, temp)
      if (n == "false") :
        print n
      else : 
        return c + n
  return "false"
    
print findNext(1, 0)

  