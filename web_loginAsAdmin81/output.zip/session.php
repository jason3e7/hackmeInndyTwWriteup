<?php

function file_in_web($file)
{
    $file = realpath($file);
    if(strpos($file, ROOT) !== 0) return false;
    return true;
}

class Session {
    private $debug;
    private $debug_dump;
    private $data;
    public $user;
    public $pass;
    public $is_admin;

    public static function login($name, $password) {
        global $users, $session;

        $user = $users[$name];
        if($user && $user['password'] === $password) {
            $session = new Session($name, $password, $user);
            $session->save();
            return true;
        }

        return false;
    }

    public static function load() {
        $data = $_COOKIE['login8cookie'];
        if(hash('sha512', $data) === $_COOKIE['login8sha512']) {
            return unserialize($data);
        } else {
            return new Session();
        }
    }

    public function __construct($user='', $pass='', $data=[]) {
        $this->debug = DEBUG_MODE;
        $this->debug_dump = 'index.php';
        $this->user = $user;
        $this->pass = $pass;
        $this->is_admin = !!$data['admin'];
        $this->data = $data;
    }

    public function save() {
        $data = serialize($this);
        $this->setcookie('login8cookie', $data);
        $this->setcookie('login8sha512', hash('sha512', $data));
    }

    private function setcookie($name, $val) {
        setcookie($name, $val, time() + 60 * 60 * 24, '/login8', '', true, true);
    }

    public function debug() {
        if($this->debug) {
            if(file_in_web($this->debug_dump)) {
                highlight_file($this->debug_dump);
            } else {
                echo 'File out of scope';
            }
        } else {
            echo 'Debug mode is not enabled';
        }
        exit;
    }
}