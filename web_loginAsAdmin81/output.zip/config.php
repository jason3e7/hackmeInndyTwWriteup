<?php
define('ROOT', dirname(realpath(__FILE__)));
define('DEBUG_MODE', false);

$flag = "FLAG{object injection G____G}";
// hidden flag: "FLAG{wake up neo}";

$users = [
    'guest' => [
        'password' => 'guest',
        'admin' => false,
    ],
    'admin' => [
        'password' => false, // admin account disabled
        'admin' => true,
    ],
];