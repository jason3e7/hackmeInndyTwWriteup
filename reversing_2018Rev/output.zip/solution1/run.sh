#!/bin/bash

fName="debug"

spChar=$'\x01'
echo $spChar

if [ ! -d "$spChar" ]; then
  mkdir $spChar
fi

cp $fName $spChar/.

sudo date -u -s "2018-01-01 00:00:00"; env -i $spChar=1 $spChar/$fName {0..2016}


