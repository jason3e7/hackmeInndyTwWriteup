#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/time.h>
#include <time.h>

void changeTime() {
  //struct tm mytime = {.tm_mday = 1, .tm_year = 118};
  struct tm mytime = {.tm_hour = 16 , .tm_year = 118};
  struct timeval garfield;
  time_t new_time;
  int result;

  new_time = mktime(&mytime);
  garfield.tv_sec = new_time;
  garfield.tv_usec = 0;

  result=settimeofday(&garfield, NULL);
  if(result < 0) {
    fprintf(stderr,"Error setting the Time.\n");
  } else {
    fprintf(stderr,"Time has been configured.\n");
  }
  return ;
}

int main(int argc, char *argv[]) {

  if (argc != 2) {
    fprintf(stderr, "Usage: %s <file-to-exec>\n", argv[0]);
    exit(EXIT_FAILURE);
  }

  changeTime();

  /* end with NULL, Why ? */  
  char *newargv[]={ [0 ... 2017] = "\x01", [2018] = NULL};
  char *newenviron[]={ "\x01", NULL};
  
  execve(argv[1], newargv, newenviron);
  perror("execve");   /* execve() returns only on error, Why ? */
  exit(EXIT_FAILURE);
}
