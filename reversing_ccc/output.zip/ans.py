import binascii
import string

crcList = [0xD641596F, 0x80A3E990, 0xC98D5C9B, 0x0D05AFAF, 0x1372A12D, 0x5D5F117B, 0x4001FBFD, 0xA7D2D56B, 0x7D04FB7E, 0x2E42895E, 0x61C97EB3, 0x84AB43C3, 0x9FC129DD, 0xF4592F4D]

#charset = string.ascii_letters + string.digits + "{} ,"
charset = string.printable

ans = ""
bad = 0

for i in range(len(crcList)) :
   index = [0, 0, 0]
   while(True) :
     string = ans + charset[index[0]] + charset[index[1]] + charset[index[2]]
     crc32 = binascii.crc32(string) & 0xffffffff
     if (crc32 == crcList[i]) :
       ans = string
       print "hit !"
       break
     index[2] += 1
     if(index[2] >= len(charset)) :
       index[2] = 0
       index[1] += 1
     if(index[1] >= len(charset)) :
       index[1] = 0
       index[0] += 1
     if(index[0] >= len(charset)) :
       bad = 1
       break
   if(bad == 1) :
     print hex(crcList[i])
     print "bad"
     break

print ans     


